#!/bin/bash

gst-launch-1.0 urisourcebin uri=file:///etc/dx-stream-sample/boat.mp4 ! decodebin ! \
	dxpreprocess preprocess-id=1 resize-width=512 resize-height=512 keep-ratio=true pad-value=114 ! \
	dxinfer preprocess-id=1 inference-id=1 model-path=./YOLOV5S_PPU.dxnn ! \
	dxpostprocess inference-id=1 library-file-path=/usr/share/dx-stream/lib/libpostprocess_ppu.so function-name=YOLOV5S_PPU ! \
	dxosd width=1280 height=720 ! \
        videoconvert ! \
	waylandsink fullscreen=false
